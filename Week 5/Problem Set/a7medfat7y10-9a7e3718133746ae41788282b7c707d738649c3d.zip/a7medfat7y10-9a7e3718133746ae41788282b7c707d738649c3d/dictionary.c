// Implements a dictionary's functionality

#include <stdbool.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <cs50.h>
#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    //LENGTH + 1 (+1) is for the '\0'
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
//as the length is the length of the biggest word 45 and assuming it's all z which is the lagest ascii value
const unsigned int N = (LENGTH * 'z');
// Hash table
node *table[N];

int total_words = 0;

// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    // TODO
    int hash_value = hash(word);
    node *cursor = table[hash_value];

    //Traverse through the linked list in each index in table
    while (cursor != NULL)
    {
        if (strcasecmp(cursor->word, word) == 0)
        {
            return true;
        }
        cursor = cursor->next;
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    // TODO
    //this hash fuction implemented from https://stackoverflow.com/questions/20462826/hash-function-for-strings-in
    unsigned int hash_value = 0;
    for (int i = 0 ; word[i] != '\0' ; i++)
    {
        hash_value = 31 * hash_value + tolower(word[i]);
    }
    return hash_value % N;
}

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
    // TODO
    FILE *file = fopen(dictionary, "r");

    if (file == NULL)
    {
        return false;
    }

    char word[LENGTH + 1];
    //loop to read each word at a time
    while (fscanf(file, "%s", word) != EOF)
    {
        node *n = malloc(sizeof(node));
        if (n == NULL)
        {
            return false;
        }
        strcpy(n->word, word);
        n->next = NULL;

        int hash_value = hash(word);

        if (table[hash_value] == NULL)
        {
            table[hash_value] = n;
        }
        else
        {
            //Add the node in the front of the table[i]
            n->next = table[hash_value];
            table[hash_value] = n;
        }
        total_words++;
    }

    fclose(file);

    return true;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    // TODO
    return total_words;
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    // TODO
    for (int i = 0; i < N; i++)
    {
        node *cursor = table[i];
        node *tmp = table[i];

        while (cursor != NULL)
        {
            cursor = cursor->next;
            free(tmp);
            tmp = cursor;
        }
    }
    return true;
}
