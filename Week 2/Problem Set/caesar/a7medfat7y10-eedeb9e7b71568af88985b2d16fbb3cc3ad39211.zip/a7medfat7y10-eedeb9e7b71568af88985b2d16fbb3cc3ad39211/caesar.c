#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    //to count the nimber of digits
    int digits = 0;
    //int key
    int key = 0;

    //if user enters two arguments
    if (argc == 2)
    {
        //loop through the argument
        for (int i = 0; i < strlen(argv[1]); i++)
        {
            //check if the argument is all digits and get the number of digits
            if (isdigit(argv[1][i]))
            {
                digits++;
            }
            //check if the argument contains all digits
            if (digits == strlen(argv[1]))
            {
                //string to intger key
                key = atoi(argv[1]) % 26;

                //get palin text from user
                string plaintext = get_string("plaintext: ");

                printf("ciphertext: ");

                //loop through the plaintext
                for (int j = 0; j < strlen(plaintext); j++)
                {
                    //if any character not alpha print same character
                    if (!isalpha(plaintext[j]))
                    {
                        printf("%c", plaintext[j]);
                        continue;
                    }
                    //if the character is alpha
                    else
                    {
                        int offset = isupper(plaintext[j]) ? 65 : 97;
                        int pi = plaintext[j] - offset;
                        int ci = (pi + key) % 26;
                        //print the ciphertext
                        printf("%c", ci + offset);
                    }
                }
                printf("\n");
                return 0;
            }

        }
    }
    //if user enters no or more than two arguments
    else
    {
        printf("Usage: ./caesar key\n");
        //make error
        return 1;
    }
}
