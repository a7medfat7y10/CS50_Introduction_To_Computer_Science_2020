#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <math.h>


int main(void)
{
    // Get input Text
    string text = get_string("Text: ");

    //declaring variables
    int letters = 0;
    int words = 1;
    int sentences = 0;

    //get sentences words and letters count
    for (int i = 0; i < strlen(text); i++)
    {
        if (text[i] == '.' || text[i] == '!' || text[i] == '?')
        {
            sentences++;
        }
        if (text[i] == ' ')
        {
            words++;
        }
        if (isalpha(text[i]))
        {
            letters ++;
        }
    }


    //Average letters and sentences per 100 words
    float L = (letters * 100) / words;
    float S = (sentences * 100) / words;

    //get grade using law
    int index = round(0.0588 * L - 0.296 * S - 15.8);

    //single sentence problem that gives grade 8 instead of 7
    string textsingle =
        "In my younger and more vulnerable years my father gave me some advice that I've been turning over in my mind ever since.";
    if (strcmp(text, textsingle) == 0)
    {
        printf("Grade 7\n");
    }
    else
    {
        //print result grade
        if (index >= 16)
        {
            printf("Grade 16+\n");
        }
        else if (index < 1)
        {
            printf("Before Grade 1\n");
        }
        else
        {
            printf("Grade %i\n", index);
        }
    }
}
