# include libraries
import sys
import csv


def main():
    # Ensure correct usage of the command line
    if len(sys.argv) != 3:
        print("You must Enter two arguments")
        exit()

    # open database file
    db_file = open(sys.argv[1], "r")
    database = csv.DictReader(db_file)

    # getting strs
    # for row in database:
    #     strs = list(row.keys())[1:]
    #     break

    strs = database.fieldnames[1:]

    # reading sequence txt file
    sequence_file = open(sys.argv[2], "r")
    sequence = sequence_file.read()
    sequence_file.close()

    # dictionary to count the patterns in dna
    dna_patterns = {}
    for str in strs:
        dna_patterns[str] = maximum_str_repeat(str, sequence)

    for row in database:
        if match(strs, dna_patterns, row):
            print(row['name'])
            db_file.close()
            return
    print("No Match")
    db_file.close()


def maximum_str_repeat(str, sequence):
    i = 0
    while str*(i+1) in sequence:
        i += 1
    return i


def match(strs, dna_patterns, row):
    for str in strs:
        if dna_patterns[str] != int(row[str]):
            return False
    return True


if __name__ == "__main__":
    main()
