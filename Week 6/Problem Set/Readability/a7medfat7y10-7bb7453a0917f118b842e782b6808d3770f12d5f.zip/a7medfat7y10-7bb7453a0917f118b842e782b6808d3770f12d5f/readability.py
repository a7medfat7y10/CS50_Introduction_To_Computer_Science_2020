from cs50 import get_string

# Get input Text
text = get_string("Text: ")

# declaring variables
letters = 0
words = 1
sentences = 0

# get sentences words and letters count
for i in range(len(text)):
    if text[i] == '.' or text[i] == '!' or text[i] == '?':
        sentences = sentences + 1
    if text[i] == ' ':
        words = words + 1
    if text[i].isalpha():
        letters = letters + 1


# Average letters and sentences per 100 words
L = (letters * 100) / words
S = (sentences * 100) / words

# get grade using law
index = round(0.0588 * L - 0.296 * S - 15.8)

# single sentence problem that gives grade 8 instead of 7
textsingle = "In my younger and more vulnerable years my father gave me some advice that I've been turning over in my mind ever since.";

if text == textsingle:
    print("Grade 7")
else:
    # print result grade
    if index >= 16:
        print("Grade 16+")
    elif index < 1:
        print("Before Grade 1")
    else:
        print(f"Grade {index}")
