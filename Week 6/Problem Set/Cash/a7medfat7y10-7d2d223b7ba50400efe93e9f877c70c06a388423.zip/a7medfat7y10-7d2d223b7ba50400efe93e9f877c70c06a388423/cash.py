from cs50 import get_float
import math

dollars = 0
cents = 0
count_25 = 0
remainer_25 = 0
count_10 = 0
remainer_10 = 0
count_5 = 0
remainer_5 = 0
count_1 = 0

# get the change in dollars from user
while True:
    # change dollars to cents
    dollars = get_float("what's change in dollars?")
    cents = dollars * 100
    if cents >= 0:
        break

# conditions if cents > 25
if cents >= 25:
    # count the 25 coins
    count_25 = math.floor(cents / 25)
    # remaining after 25
    remainer_25 = cents % 25

    if remainer_25 == 0:
        print(count_25)
    elif remainer_25 >= 10:
        # count 10 coins
        count_10 = math.floor(remainer_25 / 10)
        # remainer 10
        remainer_10 = remainer_25 % 10

        if remainer_10 == 0:
            print(count_25 + count_10)
        elif remainer_10 > 5:
            # count 5
            count_5 = math.floor(remainer_10 / 5)
            # remainer 5
            remainer_5 = remainer_10 % 5

            if remainer_5 == 0:
                print(count_25 + count_10 + count_5)
            elif remainer_5 > 0 and remainer_5 < 5:
                count_1 = remainer_5
                print(count_25 + count_10 + count_5 + count_1)

        elif remainer_10 > 0 and remainer_10 < 5:
            print(count_25 + count_10 + remainer_10)
    elif remainer_25 > 0 and remainer_25 < 5:
        print(count_25 + remainer_25)

# if cents between 10 and 25
elif cents >= 10 and cents < 25:
    # count 10
    count_10 = math.floor(cents / 10)
    # remainer 10
    remainer_10 = cents % 10
    if remainer_10 == 0:
        print(count_10)
    elif remainer_10 >= 5:
        count_5 = math.floor(remainer_10 / 5)
        remainer_5 = remainer_10 % 5
        if remainer_5 == 0:
            print(count_10 + count_5)
        elif remainer_5 > 0 and remainer_5 < 5:
            # count pennies
            count_1 = remainer_5
            print(count_10 + count_5 + count_1)
    elif remainer_10 > 0 and remainer_10 < 5:
        print(count_10 + remainer_10)
# if cents between 5 and 10
elif (cents >= 5 and cents < 10):
    count_5 = math.floor(cents / 5)
    remainer_5 = cents % 5
    if remainer_5 == 0:
        print(count_5)
    elif remainer_5 > 0 and remainer_5 < 5:
        count_1 = remainer_5
        print(count_5 + count_1)
# if all pennies
elif cents >= 1 and cents < 5:
    print(cents)