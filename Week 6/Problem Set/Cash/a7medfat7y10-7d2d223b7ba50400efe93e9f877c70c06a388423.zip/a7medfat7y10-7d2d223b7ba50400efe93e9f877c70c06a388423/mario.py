# include get_int
from cs50 import get_int

# enter numbers between 1 and 8
while True:
    height = get_int("Height:")
    if height >= 1 and height <= 8:
        break

# loop to make rows
for i in range(height):
    # loop through each row
    for j in range(height):
        if i + j >= height - 1:
            print("#", end="")
        else:
            print(" ", end="")
    print()
