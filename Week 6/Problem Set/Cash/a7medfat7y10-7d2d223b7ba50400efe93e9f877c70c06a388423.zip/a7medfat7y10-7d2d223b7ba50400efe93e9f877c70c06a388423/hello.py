# user input name
name = input("what's your name?")
# print name
print("hello, " + name)