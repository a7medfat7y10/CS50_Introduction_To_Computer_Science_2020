-- Keep a log of any SQL queries you execute as you solve the mystery.

--get the description from the crime scene reports
SELECT description FROM crime_scene_reports
WHERE day = 28 AND month = 7 AND year = 2020 AND street = "Chamberlin Street";

--description
--Theft of the CS50 duck took place at 10:15am at the Chamberlin Street courthouse.
--Interviews were conducted today with three witnesses who were present at the time — each of their interview transcripts mentions the courthouse.


--from the information we get from the description we gonna get the interview transcripts that mentions the courthouse
SELECT transcript FROM interviews WHERE year = 2020 AND month = 7 AND day = 28 AND transcript LIKE "%courthouse%";

--transcript
--Sometime within ten minutes of the theft, I saw the thief get into a car in the courthouse parking lot and drive away. If you have security footage from the courthouse parking lot, you might want to look for cars that left the parking lot in that time frame.
--I don't know the thief's name, but it was someone I recognized. Earlier this morning, before I arrived at the courthouse, I was walking by the ATM on Fifer Street and saw the thief there withdrawing some money.
--As the thief was leaving the courthouse, they called someone who talked to them for less than a minute. In the call, I heard the thief say that they were planning to take the earliest flight out of Fiftyville tomorrow. The thief then asked the person on the other end of the phone to purchase the flight ticket.

--now we got our three transcripts on the same day and contains courthouse


--Based on the first transcript "Sometime within ten minutes of the theft, I saw the thief get into a car in the courthouse parking lot and drive away. If you have security footage from the courthouse parking lot, you might want to look for cars that left the parking lot in that time frame."
--we get the people who exit from the courthouse within ten minutes by their license_plate
SELECT name FROM people JOIN courthouse_security_logs ON courthouse_security_logs.license_plate = people.license_plate
WHERE day = 28 AND month = 7 AND year = 2020 AND hour = 10 AND minute >= 15 AND minute <= 25 AND activity = "exit";

--Now We get the names of the suspects based on the first transcript
-- Patrick
-- Ernest
-- Amber
-- Danielle
-- Roger
-- Elizabeth
-- Russell
-- Evelyn



--Based on the second transcript: "I don't know the thief's name, but it was someone I recognized. Earlier this morning, before I arrived at the courthouse, I was walking by the ATM on Fifer Street and saw the thief there withdrawing some money."
--we get the people withdraw money from the atm on fifer street this morning
SELECT distinct(name) FROM people JOIN bank_accounts ON bank_accounts.person_id = people.id JOIN atm_transactions ON bank_accounts.account_number = atm_transactions.account_number
WHERE day = "28" AND month = "7" AND year = "2020" AND transaction_type = "withdraw" AND atm_location = "Fifer Street";

-- Now We get the names of the suspects based on the second transcript:
-- Danielle
-- Bobby
-- Madison
-- Ernest
-- Roy
-- Elizabeth
-- Victoria
-- Russell


--Based on the third transcript:"As the thief was leaving the courthouse, they called someone who talked to them for less than a minute. In the call, I heard the thief say that they were planning to take the earliest flight out of Fiftyville tomorrow. The thief then asked the person on the other end of the phone to purchase the flight ticket."
--we get the people who made a phone call less than a minute "60 sec"
SELECT name FROM people JOIN phone_calls ON people.phone_number = phone_calls.caller WHERE day = "28" AND month = "7" AND year = "2020" AND duration < "60";
--we get the people who left fiftyville on the first flight
SELECT name FROM people JOIN passengers ON people.passport_number = passengers.passport_number WHERE flight_id = (
SELECT id FROM flights WHERE day = "29" AND month = "7" AND year = "2020" ORDER BY hour, minute LIMIT 1);

-- Now we got the peoplo who made a phone call less than a minute "60 sec"
-- Roger
-- Evelyn
-- Ernest
-- Evelyn
-- Madison
-- Russell
-- Kimberly
-- Bobby
-- Victoria

--Now we got the peoplo who left on the first flight
-- name
-- Doris
-- Roger
-- Ernest
-- Edward
-- Evelyn
-- Madison
-- Bobby
-- Danielle



--Now we have four group of names contains the suspects based on the three transcripts and the thief must be in all of them

--get the intersect of the four queries to get the thief
SELECT name FROM people JOIN courthouse_security_logs ON courthouse_security_logs.license_plate = people.license_plate
WHERE day = 28 AND month = 7 AND year = 2020 AND hour = 10 AND minute >= 15 AND minute <= 25 AND activity = "exit"
INTERSECT
SELECT distinct(name) FROM people JOIN bank_accounts ON bank_accounts.person_id = people.id JOIN atm_transactions ON bank_accounts.account_number = atm_transactions.account_number
WHERE day = "28" AND month = "7" AND year = "2020" AND transaction_type = "withdraw" AND atm_location = "Fifer Street"
INTERSECT
SELECT name FROM people JOIN phone_calls ON people.phone_number = phone_calls.caller WHERE day = "28" AND month = "7" AND year = "2020" AND duration < "60"
INTERSECT
SELECT name FROM people JOIN passengers ON people.passport_number = passengers.passport_number WHERE flight_id = (
SELECT id FROM flights WHERE day = "29" AND month = "7" AND year = "2020" ORDER BY hour, minute LIMIT 1);

-- The thief is Ernest


-- Now we can get the destination knowing that he got on the first flight the next day
SELECT city FROM airports WHERE id = (SELECT destination_airport_id FROM flights WHERE day = "29" AND month = "7" AND year = "2020" ORDER BY hour, minute LIMIT 1);
--The dextination is London



-- Now we can get the accompilce knowing that he recived a call from Ernest on 28/7/2020 less than one minute
SELECT name FROM people JOIN phone_calls ON people.phone_number = phone_calls.receiver WHERE day = "28" AND month = "7" AND year = "2020" AND duration < "60"
AND caller = ( SELECT phone_number FROM people WHERE name = "Ernest");
-- the accomilce is Berthold