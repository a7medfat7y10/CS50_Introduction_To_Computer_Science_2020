#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <cs50.h>

int main(int argc, char *argv[])
{
    //if more than one argument
    if (argc != 2)
    {
        printf("Usage: ./recover image\n");
        return 1;
    }

    //open file to read
    FILE *file = fopen(argv[1], "r");
    //if file
    if (file == NULL)
    {
        printf("Could not open file\n");
        return 1;
    }

    //buffer for block contains 512 bytes
    typedef uint8_t BYTE;
    BYTE buffer[512];

    //create current file
    FILE *current_file;
    char current_filename[100]; //as at most there are 50 files
    int current_filenumber = 0; //first file will be 000

    bool is_jpeg = false;

    //if file can be read
    while (fread(buffer, sizeof(buffer), 1, file) == 1)
    {
        //if first 4 bytes for jpeg
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {
            //the file is jpeg
            is_jpeg = true;

            sprintf(current_filename, "%03i.jpg", current_filenumber);
            current_file = fopen(current_filename, "w");
            fwrite(buffer, sizeof(buffer), 1, current_file);
            current_filenumber++;

        }
        //if block doesnot start with these 4 bytes
        else
        {
            //check if is_jpeg == true and continue writing in current file
            if (is_jpeg)
            {
                fwrite(buffer, sizeof(buffer), 1, current_file);
            }
        }
    }

    fclose(file);
    fclose(current_file);

    return 0;
}